import cv2
import numpy as np
import os
from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import RedirectResponse
import uvicorn

app = FastAPI(title="AOI Classification & Template Management API", version="4.0")

# 確保範本儲存目錄存在
TEMPLATE_DIR = "./local_output/templates"
os.makedirs(TEMPLATE_DIR, exist_ok=True)

# 根據您先前最佳化算出的各系列 ROI 座標與對應的差值門檻 (min_diff)
CATEGORY_CONFIGS = {
    "01_Series": {
        "rx1": 0.55, "ry1": 0.55, "rx2": 0.65, "ry2": 0.65,
        "min_diff_threshold": 50.0,  # 01 類別的差值門檻
        "ncc_threshold": 0.50
    },
    "02_Series": {
        "rx1": 0.20, "ry1": 0.60, "rx2": 0.30, "ry2": 0.65,
        "min_diff_threshold": 15.0,  # 02 類別的差值門檻
        "ncc_threshold": 0.50
    }
}

# 根目錄自動導向測試介面
@app.get("/", include_in_schema=False)
def read_root():
    return RedirectResponse(url="/docs")


# 1. 第一步：上傳該類別的標準 Down 圖片來建立/更新 Template
@app.post("/api/v1/template/upload")
async def upload_template(
    category: str = Form(..., description="請選擇類別: 01_Series 或 02_Series"),
    file: UploadFile = File(..., description="請上傳該類別標準的 Down (Contact) 圖片")
):
    if category not in CATEGORY_CONFIGS:
        raise HTTPException(status_code=400, detail=f"不支援的類別，僅支援: {list(CATEGORY_CONFIGS.keys())}")
    
    contents = await file.read()
    nparr = np.frombuffer(contents, np.uint8)
    img_bgr = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    if img_bgr is None:
        raise HTTPException(status_code=400, detail="無法解析上傳的圖片檔案")
    
    h, w = img_bgr.shape[:2]
    cfg = CATEGORY_CONFIGS[category]
    x1, y1 = int(w * cfg["rx1"]), int(h * cfg["ry1"])
    x2, y2 = int(w * cfg["rx2"]), int(h * cfg["ry2"])
    
    # 根據最佳 ROI 擷取範本
    template_roi = img_bgr[y1:y2, x1:x2]
    if template_roi.size == 0:
        raise HTTPException(status_code=500, detail="計算出的 ROI 範圍無效")
        
    # 儲存為該類別的標準 Down 範本
    template_path = os.path.join(TEMPLATE_DIR, f"template_{category}.jpg")
    cv2.imwrite(template_path, template_roi)
    
    return {
        "message": f"成功為 [{category}] 註冊標準 Down 範本！",
        "template_path": template_path,
        "applied_roi": {"rx1": cfg["rx1"], "ry1": cfg["ry1"], "rx2": cfg["rx2"], "ry2": cfg["ry2"]}
    }


# 2. 第二步：上傳任意測試圖片進行即時比對與預測
@app.post("/api/v1/predict")
async def predict_image(
    category: str = Form(..., description="請選擇類別: 01_Series 或 02_Series"),
    file: UploadFile = File(..., description="請上傳要檢測的測試圖片")
):
    if category not in CATEGORY_CONFIGS:
        raise HTTPException(status_code=400, detail=f"不支援的類別，僅支援: {list(CATEGORY_CONFIGS.keys())}")
    
    # 檢查該類別是否已經上傳過 Template
    template_path = os.path.join(TEMPLATE_DIR, f"template_{category}.jpg")
    if not os.path.exists(template_path):
        raise HTTPException(
            status_code=400, 
            detail=f"[{category}] 尚未設定 Template！請先透過 /api/v1/template/upload 上傳該類別的標準 Down 圖片。"
        )
        
    # 讀取測試圖片
    contents = await file.read()
    nparr = np.frombuffer(contents, np.uint8)
    img_bgr = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    if img_bgr is None:
        raise HTTPException(status_code=400, detail="無法解析上傳的測試圖片檔案")
    
    h, w = img_bgr.shape[:2]
    cfg = CATEGORY_CONFIGS[category]
    x1, y1 = int(w * cfg["rx1"]), int(h * cfg["ry1"])
    x2, y2 = int(w * cfg["rx2"]), int(h * cfg["ry2"])
    
    roi = img_bgr[y1:y2, x1:x2]
    if roi.size == 0:
        raise HTTPException(status_code=500, detail="計算出的 ROI 範圍無效")
        
    gray_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    
    # 計算測試圖片的拉普拉斯清晰度分數
    blurred = cv2.GaussianBlur(gray_roi, (5, 5), 0)
    lap_score = float(cv2.Laplacian(blurred, cv2.CV_64F).var())
    
    # 讀取該類別的 Down Template 並計算 NCC 匹配分數
    template_img = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)
    ncc_score = 0.0
    
    if template_img.shape[0] <= gray_roi.shape[0] and template_img.shape[1] <= gray_roi.shape[1]:
        match_result = cv2.matchTemplate(gray_roi, template_img, cv2.TM_CCOEFF_NORMED)
        _, ncc_score, _, _ = cv2.minMaxLoc(match_result)
        ncc_score = float(ncc_score)
        
    # 判斷邏輯：比對清晰度是否達到該類別的門檻 (01: 50.0, 02: 15.0) 且 NCC 滿足條件
    target_diff = cfg["min_diff_threshold"]
    is_contact = (lap_score >= target_diff) and (ncc_score >= cfg["ncc_threshold"])
    status = "Down (Contact)" if is_contact else "Up (Non-contact)"
    
    return {
        "filename": file.filename,
        "category": category,
        "laplacian_score": round(lap_score, 2),
        "target_diff_threshold": target_diff,
        "ncc_score": round(ncc_score, 4),
        "ncc_threshold": cfg["ncc_threshold"],
        "prediction": status
    }

if __name__ == "__main__":
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=True)